from appJar import gui
from Quiz_database import *
from Tkinter import *
import MySQLdb
import os



class hell:
    def __init__(self, app):    
        self.app = app
        self.a = 0
        self.x = 0
        self.get_data()        
    
    
    
    def get_data(self):
        cur.execute("SELECT * FROM questions_table")
        rows = cur.fetchall()
        print rows
        # for row in rows:
        # print row
        app.addLabel("Question", rows[self.x][0], 0, 0, colspan=4)
        # app.setEntry("Question", row[0])
        print rows[self.x][0]
        opt=app.addRadioButton("option", rows[self.x][1])
        print rows[self.x][1]
        opt=app.addRadioButton("option",rows[self.x][2])
        print rows[self.x][2]
        opt=app.addRadioButton("option", rows[self.x][3])
        print rows[self.x][3]
        opt=app.addRadioButton("option", rows[self.x][4])
        print rows[self.x][4]
        self.r = rows[self.x][5]
        print rows[self.x][5]
        print "Hello"

        # self.app=app
        app.addButton("CONFIRM", self.dat)


    def dat(self, button):
        self.a = (self.app.getRadioButton("option"))
        if self.a != self.r:
            app.errorBox("wrans","WRONG ANSWER!!!!")
        else:
            app.infoBox("rans","RIGHT ANSWER!!!!")
        # if r==opt:
        #     print'You got one score!!'
        # else:
        #     print 'You didnt get any score'

        self.x += 1
        self.app.removeAllWidgets()
        self.get_data()
        print (self.app.getRadioButton("option"))
        # if self.r == self.opt:
        #     print 'Right Answer'
        # else:
        #     print 'Wrong Answer'
        # self.adder()

    # def adder(self,r,opt):



if __name__ == '__main__':
    app = gui("QUIZ", "400x400")
    app.setBg("white")
    app.setFont(12)
    app.setFg("black")

    hell(app)
    app.go()
    

    