from appJar import gui
from questions_database import *
import os
import MySQLdb

class hello1:
    def press(self,app):
        print "OK"
        crs = self.app.getEntry("Course")
        nq = self.app.getEntry("No.of questions")
        tim = self.app.getEntry("Time")
        #print a + b + c + d + ri + ques
        cur.execute("Insert into quiz values(%s,%s,%s)", (crs,nq,tim))
        # db.autocommit(True)
        db.commit()
        # app.hide()
        os.system("python questions.py")
        self.app.stop()


    def __init__(self):

        app = gui("QUIZ INFO", "400x200")
        app.setBg("black")
        app.setFont(15)
        self.app = app
        # add & configure widgets - widgets get a name, to help referencing them later
        app.addLabel("title", "QUIZ FORM")
        app.setLabelBg("title", "grey")
        app.setLabelFg("title", "black")
        app.addLabelEntry("Course")
        app.setFg("white")
        app.addLabelEntry("No.of questions")
        app.addLabelEntry("Time")
        app.addButtons(["OK","CANCEL"],self.press)
        # link the buttons to the function called press

        app.setFocus("Course")
        #app
        # start the GUI
        app.go()
hello1()





# # import the library
# from appJar import gui
# from Quiz_database import *
#
# # from data import *
#
#
# # handle button events
# # create a GUI variable called app
# class hello1:
#
#     # def _init(self,app):
#     #     print "s"
#     #     return
#     def press(self,app):
#         print "OK"
#         crs = self.app.getEntry("Course")
#         nq = self.app.getEntry("No.of questions")
#         tim = self.app.getEntry("Time")
#         #print a + b + c + d + ri + ques
#         cur.execute("Insert into questions_table values(%s,%d,%s)", (crs,nq,tim))
#         # db.autocommit(True)
#         db.commit()
#
#     def __init__(self):
#         app = gui("Login Window", "400x200")
#         app.setBg("black")
#         app.setFont(15)
#         # add & configure widgets - widgets get a name, to help referencing them later
#         app.addLabel("title", "QUIZ FORM")
#         app.setLabelBg("title", "grey")
#         app.setLabelFg("title", "black")
#         app.addLabelEntry("Course")
#         app.setLabelFg("Course", "white")
#         app.addLabelEntry("No.of questions")
#         app.setLabelFg("No.of questions", "white")
#         app.addLabelEntry("Time")
#         app.setLabelFg("Time", "white")
#         app.addButtons(["OK","CANCEL"],self.press)
#         # link the buttons to the function called press
#
#         app.setFocus("Course")
#
#         # start the GUI
#         app.go()
#
#
