
import form_login
from quiz import *
from student_quiz import *
from teacher_quiz import *
import questions
import unittest
import atexit

class mytests(unittest.TestCase):
    def name(self):
        self.assertEquals(self.usr, 'Asbah')
        print 'Test pass'
    def name(self):
        self.assertEquals(self.usr, 'Eeman')

    def name(self):
        self.assertEquals(self.usr, 'Imran')

    def name(self):
        self.assertEquals(self.pwd, 'asb')

    def name(self):
        self.assertEquals(self.pwd, 'imr')


if __name__ == '_main_':
    app = gui()
    unittest.main()
