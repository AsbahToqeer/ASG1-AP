from appJar import gui
from questions_database import *
from Tkinter import *
import MySQLdb

class hello:

    def press(self,app):
        print "hello"
        ques = self.app.getEntry("Question")
        a = self.app.getEntry("A-")
        b = self.app.getEntry("B-")
        c = self.app.getEntry("C-")
        d = self.app.getEntry("D-")
        ri = self.app.getEntry("Right Answer")
        print a + b + c + d + ri + ques
        cur.execute("Insert into questions_table VALUES(%s,%s,%s,%s,%s,%s)", (ques, a, b, c, d, ri))

        self.app.clearAllEntries()

    def __init__(self):
        for i in range(1,10):
            app = gui("QUIZ", "400x400")
            app.setBg("black")
            app.setFont(12)
            self.app = app
            app.addLabelEntry("Question",colspan=4)
            app.setFg("white")
            app.addLabelEntry("A-",1,0,colspan=2)
            app.addLabelEntry("B-",1,1,colspan=2)
            app.addLabelEntry("C-", 2, 0,colspan=2)
            app.addLabelEntry("D-",2,1,colspan=2)
            app.addLabelEntry("Right Answer", 3, 0)
            app.addButton("CONFIRM", self.press)
            app.setFocus("Question")
            app.go()
hello()