# import the library

import os
from appJar import gui
from database import *
import yappi

def press(button):
    if button == "Cancel":
        app.stop()
    else:
        usr = app.getEntry("Username")
        pwd = app.getEntry("Password")
        print("Username:", usr, "Password:", pwd)
        for x in rows:
            if usr == x[1] and pwd == x[2] and x[3] == "stu":
                app.infoBox("Success", "Congratulations, you are logged in as a student!")
                # app.hide()
                os.system("python student_quiz.py")
                # os.system("python quiz.py")
                os.system("python quiz.py")
                return
            elif usr == x[1] and pwd == x[2] and x[3] == "teacher":
                app.infoBox("Success", "Congratulations, you are logged in as a teacher!")
                app.hide()
                os.system("python teacher_quiz.py")
                # os.system("python quiz_window.py")

                app.hide()
                os.system("python questions.py")



                # os.system("python questions.py")

                # app.hide()
                # app.removeAllWidgets()
                # press(rb)
                return
        app.errorBox("Failed login", "Invalid password or username")
        return

yappi.start()
if __name__ == '__main__':
    # create a GUI variable called app
    app = gui("Login Window", "400x200")
    app.setBg("black")
    app.setFont(15)

    # add & configure widgets - widgets get a name, to help referencing them later
    app.addLabel("title", "LOGIN FORM")
    app.setLabelBg("title", "grey")
    app.setLabelFg("title", "black")

    app.addLabelEntry("Username")
    app.setLabelFg("Username", "white")
    app.addLabelSecretEntry("Password")
    app.setLabelFg("Password", "white")

    # link the buttons to the function called press
    app.addButtons(["Submit", "Cancel"], press)
    app.setFocus("Username")

    # start the GUI
    app.go()



# main()

yappi.get_func_stats().print_all()

yappi.get_thread_stats().print_all()
print yappi.get_mem_usage()