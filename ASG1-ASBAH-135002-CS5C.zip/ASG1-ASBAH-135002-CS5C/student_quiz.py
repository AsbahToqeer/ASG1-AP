from appJar import gui
import os
class stu:

    def press(self,app):
        print 'ok'
        # app.hide()
        os.system("python quiz.py")

    def __init__(self):
        app=gui("Choose subject","600x600")
        app.setBg("black")
        app.setFg("white")
        app.setFont(15)
        app.addLabel("sub","WELCOME TO THE QUIZ.BEST OF LUCK!!!!")
        # app.addButton("ADVANCED PROGRAMMING",self.press)
        app.addButton("START QUIZ",self.press)
        app.go()
stu()