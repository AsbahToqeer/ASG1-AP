# from appJar import gui
# from questions_database import *
# from Tkinter import *
# import MySQLdb
# #window=tkinter.Tk()
# #btn=None
#
# class quiz:
#     def press(self,app):
#         print 'Start the quiz'
#         # self.app.stop()
#
#     # def __init__(self):
#     app = gui("QUIZ", "300x300")
#     app.setBg("black")
#     app.setFont(12)
#     # self.app = app
#     # app.addLabelEntry("Question#2")
#     # app.setaddMessageFg("white")
#     app.addButton("START QUIZ", press)
#
#
# quiz()



from appJar import gui
import os

class stu:

    def press(self,app):
        # print 'ok'
        # app.hide(self)
        os.system("python quiz_window.py")
        # os.system("python true/false.py")

    def __init__(self):
        app=gui("Choose subject","400x400")
        app.setBg("black")
        app.setFg("white")
        app.setFont(15)
        app.addLabel("sub","START MAKING QUIZ")
        app.addButton("START",self.press)
        # app.hide()
        app.go()
stu()