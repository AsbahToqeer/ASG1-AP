import MySQLdb
#import questions
db = MySQLdb.connect(host="127.0.0.1",    # your host, usually localhost
                     user="root",         # your username
                     passwd="root",  # your password
                     db="login_form")        # name of the data base

# you must create a Cursor object. It will let
#  you execute all the queries you need
cur = db.cursor()
#db.autocommit(True)
# Use all the SQL you like
cur.execute("SELECT * FROM questions_table")
#cur.execute("Insert into questions_table values(ques,a,b,c,d,right)")


# print all the first cell of all the rows
rw = cur.fetchall()


